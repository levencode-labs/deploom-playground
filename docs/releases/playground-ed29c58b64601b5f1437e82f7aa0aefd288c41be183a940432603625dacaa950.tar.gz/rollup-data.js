'use strict';

// npm 10.9.2, Node 24.18.0, Windows x64. Public Rollup pinned for this fixture.
// npm install --os=darwin --cpu=arm64 --ignore-scripts --no-audit --no-fund
// Run twice, renaming package-lock.json and retaining node_modules between runs.
(() => {
  const before = {
    "name": "rollup-platforms",
    "version": "1.0.0",
    "lockfileVersion": 3,
    "requires": true,
    "packages": {
      "": {
        "name": "rollup-platforms",
        "version": "1.0.0",
        "devDependencies": {
          "rollup": "4.28.0"
        }
      },
      "node_modules/@rollup/rollup-android-arm-eabi": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-android-arm-eabi/-/rollup-android-arm-eabi-4.28.0.tgz",
        "integrity": "sha512-wLJuPLT6grGZsy34g4N1yRfYeouklTgPhH1gWXCYspenKYD0s3cR99ZevOGw5BexMNywkbV3UkjADisozBmpPQ==",
        "cpu": [
          "arm"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "android"
        ]
      },
      "node_modules/@rollup/rollup-android-arm64": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-android-arm64/-/rollup-android-arm64-4.28.0.tgz",
        "integrity": "sha512-eiNkznlo0dLmVG/6wf+Ifi/v78G4d4QxRhuUl+s8EWZpDewgk7PX3ZyECUXU0Zq/Ca+8nU8cQpNC4Xgn2gFNDA==",
        "cpu": [
          "arm64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "android"
        ]
      },
      "node_modules/@rollup/rollup-darwin-arm64": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-darwin-arm64/-/rollup-darwin-arm64-4.28.0.tgz",
        "integrity": "sha512-lmKx9yHsppblnLQZOGxdO66gT77bvdBtr/0P+TPOseowE7D9AJoBw8ZDULRasXRWf1Z86/gcOdpBrV6VDUY36Q==",
        "cpu": [
          "arm64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "darwin"
        ]
      },
      "node_modules/@rollup/rollup-darwin-x64": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-darwin-x64/-/rollup-darwin-x64-4.28.0.tgz",
        "integrity": "sha512-8hxgfReVs7k9Js1uAIhS6zq3I+wKQETInnWQtgzt8JfGx51R1N6DRVy3F4o0lQwumbErRz52YqwjfvuwRxGv1w==",
        "cpu": [
          "x64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "darwin"
        ]
      },
      "node_modules/@rollup/rollup-freebsd-arm64": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-freebsd-arm64/-/rollup-freebsd-arm64-4.28.0.tgz",
        "integrity": "sha512-lA1zZB3bFx5oxu9fYud4+g1mt+lYXCoch0M0V/xhqLoGatbzVse0wlSQ1UYOWKpuSu3gyN4qEc0Dxf/DII1bhQ==",
        "cpu": [
          "arm64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "freebsd"
        ]
      },
      "node_modules/@rollup/rollup-freebsd-x64": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-freebsd-x64/-/rollup-freebsd-x64-4.28.0.tgz",
        "integrity": "sha512-aI2plavbUDjCQB/sRbeUZWX9qp12GfYkYSJOrdYTL/C5D53bsE2/nBPuoiJKoWp5SN78v2Vr8ZPnB+/VbQ2pFA==",
        "cpu": [
          "x64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "freebsd"
        ]
      },
      "node_modules/@rollup/rollup-linux-arm-gnueabihf": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-arm-gnueabihf/-/rollup-linux-arm-gnueabihf-4.28.0.tgz",
        "integrity": "sha512-WXveUPKtfqtaNvpf0iOb0M6xC64GzUX/OowbqfiCSXTdi/jLlOmH0Ba94/OkiY2yTGTwteo4/dsHRfh5bDCZ+w==",
        "cpu": [
          "arm"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-arm-musleabihf": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-arm-musleabihf/-/rollup-linux-arm-musleabihf-4.28.0.tgz",
        "integrity": "sha512-yLc3O2NtOQR67lI79zsSc7lk31xjwcaocvdD1twL64PK1yNaIqCeWI9L5B4MFPAVGEVjH5k1oWSGuYX1Wutxpg==",
        "cpu": [
          "arm"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-arm64-gnu": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-arm64-gnu/-/rollup-linux-arm64-gnu-4.28.0.tgz",
        "integrity": "sha512-+P9G9hjEpHucHRXqesY+3X9hD2wh0iNnJXX/QhS/J5vTdG6VhNYMxJ2rJkQOxRUd17u5mbMLHM7yWGZdAASfcg==",
        "cpu": [
          "arm64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-arm64-musl": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-arm64-musl/-/rollup-linux-arm64-musl-4.28.0.tgz",
        "integrity": "sha512-1xsm2rCKSTpKzi5/ypT5wfc+4bOGa/9yI/eaOLW0oMs7qpC542APWhl4A37AENGZ6St6GBMWhCCMM6tXgTIplw==",
        "cpu": [
          "arm64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-powerpc64le-gnu": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-powerpc64le-gnu/-/rollup-linux-powerpc64le-gnu-4.28.0.tgz",
        "integrity": "sha512-zgWxMq8neVQeXL+ouSf6S7DoNeo6EPgi1eeqHXVKQxqPy1B2NvTbaOUWPn/7CfMKL7xvhV0/+fq/Z/J69g1WAQ==",
        "cpu": [
          "ppc64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-riscv64-gnu": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-riscv64-gnu/-/rollup-linux-riscv64-gnu-4.28.0.tgz",
        "integrity": "sha512-VEdVYacLniRxbRJLNtzwGt5vwS0ycYshofI7cWAfj7Vg5asqj+pt+Q6x4n+AONSZW/kVm+5nklde0qs2EUwU2g==",
        "cpu": [
          "riscv64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-s390x-gnu": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-s390x-gnu/-/rollup-linux-s390x-gnu-4.28.0.tgz",
        "integrity": "sha512-LQlP5t2hcDJh8HV8RELD9/xlYtEzJkm/aWGsauvdO2ulfl3QYRjqrKW+mGAIWP5kdNCBheqqqYIGElSRCaXfpw==",
        "cpu": [
          "s390x"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-x64-gnu": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-x64-gnu/-/rollup-linux-x64-gnu-4.28.0.tgz",
        "integrity": "sha512-Nl4KIzteVEKE9BdAvYoTkW19pa7LR/RBrT6F1dJCV/3pbjwDcaOq+edkP0LXuJ9kflW/xOK414X78r+K84+msw==",
        "cpu": [
          "x64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-linux-x64-musl": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-linux-x64-musl/-/rollup-linux-x64-musl-4.28.0.tgz",
        "integrity": "sha512-eKpJr4vBDOi4goT75MvW+0dXcNUqisK4jvibY9vDdlgLx+yekxSm55StsHbxUsRxSTt3JEQvlr3cGDkzcSP8bw==",
        "cpu": [
          "x64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "linux"
        ]
      },
      "node_modules/@rollup/rollup-win32-arm64-msvc": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-win32-arm64-msvc/-/rollup-win32-arm64-msvc-4.28.0.tgz",
        "integrity": "sha512-Vi+WR62xWGsE/Oj+mD0FNAPY2MEox3cfyG0zLpotZdehPFXwz6lypkGs5y38Jd/NVSbOD02aVad6q6QYF7i8Bg==",
        "cpu": [
          "arm64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "win32"
        ]
      },
      "node_modules/@rollup/rollup-win32-ia32-msvc": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-win32-ia32-msvc/-/rollup-win32-ia32-msvc-4.28.0.tgz",
        "integrity": "sha512-kN/Vpip8emMLn/eOza+4JwqDZBL6MPNpkdaEsgUtW1NYN3DZvZqSQrbKzJcTL6hd8YNmFTn7XGWMwccOcJBL0A==",
        "cpu": [
          "ia32"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "win32"
        ]
      },
      "node_modules/@rollup/rollup-win32-x64-msvc": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/@rollup/rollup-win32-x64-msvc/-/rollup-win32-x64-msvc-4.28.0.tgz",
        "integrity": "sha512-Bvno2/aZT6usSa7lRDL2+hMjVAGjuqaymF1ApZm31JXzniR/hvr14jpU+/z4X6Gt5BPlzosscyJZGUvguXIqeQ==",
        "cpu": [
          "x64"
        ],
        "dev": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "win32"
        ]
      },
      "node_modules/@types/estree": {
        "version": "1.0.6",
        "resolved": "https://registry.npmjs.org/@types/estree/-/estree-1.0.6.tgz",
        "integrity": "sha512-AYnb1nQyY49te+VRAVgmzfcgjYS91mY5P0TKUDCLEM+gNnA+3T6rWITXRLYCpahpqSQbN5cE+gHpnPyXjHWxcw==",
        "dev": true,
        "license": "MIT"
      },
      "node_modules/fsevents": {
        "version": "2.3.3",
        "resolved": "https://registry.npmjs.org/fsevents/-/fsevents-2.3.3.tgz",
        "integrity": "sha512-5xoDfX+fL7faATnagmWPpbFtwh/R77WmMMqqHGS65C3vvB0YHrgF+B1YmZ3441tMj5n63k0212XNoJwzlhffQw==",
        "dev": true,
        "hasInstallScript": true,
        "license": "MIT",
        "optional": true,
        "os": [
          "darwin"
        ],
        "engines": {
          "node": "^8.16.0 || ^10.6.0 || >=11.0.0"
        }
      },
      "node_modules/rollup": {
        "version": "4.28.0",
        "resolved": "https://registry.npmjs.org/rollup/-/rollup-4.28.0.tgz",
        "integrity": "sha512-G9GOrmgWHBma4YfCcX8PjH0qhXSdH8B4HDE2o4/jaxj93S4DPCIDoLcXz99eWMji4hB29UFCEd7B2gwGJDR9cQ==",
        "dev": true,
        "license": "MIT",
        "dependencies": {
          "@types/estree": "1.0.6"
        },
        "bin": {
          "rollup": "dist/bin/rollup"
        },
        "engines": {
          "node": ">=18.0.0",
          "npm": ">=8.0.0"
        },
        "optionalDependencies": {
          "@rollup/rollup-android-arm-eabi": "4.28.0",
          "@rollup/rollup-android-arm64": "4.28.0",
          "@rollup/rollup-darwin-arm64": "4.28.0",
          "@rollup/rollup-darwin-x64": "4.28.0",
          "@rollup/rollup-freebsd-arm64": "4.28.0",
          "@rollup/rollup-freebsd-x64": "4.28.0",
          "@rollup/rollup-linux-arm-gnueabihf": "4.28.0",
          "@rollup/rollup-linux-arm-musleabihf": "4.28.0",
          "@rollup/rollup-linux-arm64-gnu": "4.28.0",
          "@rollup/rollup-linux-arm64-musl": "4.28.0",
          "@rollup/rollup-linux-powerpc64le-gnu": "4.28.0",
          "@rollup/rollup-linux-riscv64-gnu": "4.28.0",
          "@rollup/rollup-linux-s390x-gnu": "4.28.0",
          "@rollup/rollup-linux-x64-gnu": "4.28.0",
          "@rollup/rollup-linux-x64-musl": "4.28.0",
          "@rollup/rollup-win32-arm64-msvc": "4.28.0",
          "@rollup/rollup-win32-ia32-msvc": "4.28.0",
          "@rollup/rollup-win32-x64-msvc": "4.28.0",
          "fsevents": "~2.3.2"
        }
      }
    }
  };
  // Every record retained by the second npm install was identical to its original.
  const retained = [
    "",
    "node_modules/@rollup/rollup-darwin-arm64",
    "node_modules/@types/estree",
    "node_modules/fsevents",
    "node_modules/rollup"
  ];
  const after = {...before, packages:Object.fromEntries(retained.map(path=>[path,before.packages[path]]))};
  window.RollupLab = {before,after};
})();
