'use strict';
// Public css-select baseline: npm packument dates and /v1/query for each exact installed identity.
window.LabAuditCapture = {
  "captured": "2026-11-21",
  "packument": {
    "name": "css-select",
    "versions": {
      "1.0.0": {},
      "1.1.0": {},
      "1.2.0": {},
      "1.3.0-rc0": {},
      "2.0.0": {},
      "2.0.2": {},
      "2.1.0": {},
      "3.0.0": {},
      "3.0.1": {},
      "3.0.2": {},
      "3.0.3": {},
      "3.0.4": {},
      "3.1.0": {},
      "3.1.1": {},
      "3.1.2": {},
      "4.0.0": {},
      "4.1.0": {},
      "4.1.1": {},
      "4.1.2": {},
      "4.1.3": {},
      "4.2.0": {},
      "4.2.1": {},
      "4.3.0": {},
      "5.0.0": {},
      "5.0.1": {},
      "5.1.0": {},
      "5.2.0": {},
      "5.2.1": {},
      "5.2.2": {},
      "6.0.0": {},
      "7.0.0": {}
    },
    "time": {
      "created": "2015-02-03T22:19:31.872Z",
      "modified": "2026-03-22T22:44:26.765Z",
      "1.0.0": "2015-02-03T22:19:31.872Z",
      "1.1.0": "2015-03-06T09:56:07.297Z",
      "1.2.0": "2015-11-24T00:18:41.364Z",
      "1.3.0-rc0": "2017-01-19T11:01:49.162Z",
      "2.0.0": "2018-03-09T13:24:17.585Z",
      "2.0.2": "2018-10-21T22:49:43.146Z",
      "2.1.0": "2019-11-09T23:15:02.442Z",
      "3.0.0": "2020-09-23T21:00:03.773Z",
      "3.0.1": "2020-09-23T23:38:16.650Z",
      "3.0.2": "2020-09-27T19:37:42.559Z",
      "3.0.3": "2020-09-28T02:28:08.241Z",
      "3.0.4": "2020-10-01T20:53:51.493Z",
      "3.1.0": "2020-10-02T16:59:00.899Z",
      "3.1.1": "2020-12-08T23:27:23.037Z",
      "3.1.2": "2020-12-10T20:54:41.127Z",
      "4.0.0": "2021-04-03T08:00:28.226Z",
      "4.1.0": "2021-04-16T09:22:34.648Z",
      "4.1.1": "2021-04-16T09:34:40.542Z",
      "4.1.2": "2021-04-16T09:42:37.437Z",
      "4.1.3": "2021-06-06T15:43:37.009Z",
      "4.2.0": "2021-12-14T16:01:41.038Z",
      "4.2.1": "2021-12-26T11:38:44.447Z",
      "4.3.0": "2022-03-28T13:57:10.490Z",
      "5.0.0": "2022-04-24T18:27:03.139Z",
      "5.0.1": "2022-04-25T11:57:32.440Z",
      "5.1.0": "2022-04-27T18:29:37.203Z",
      "5.2.0": "2025-06-28T10:11:28.343Z",
      "5.2.1": "2025-06-28T11:03:13.607Z",
      "5.2.2": "2025-06-28T15:49:53.402Z",
      "6.0.0": "2025-06-29T17:21:03.629Z",
      "7.0.0": "2026-03-22T22:44:26.452Z"
    }
  },
  "results": {
    "boolbase@1.0.0": [],
    "css-select@2.1.0": [],
    "css-what@3.4.2": [],
    "dom-serializer@0.2.2": [],
    "domelementtype@2.3.0": [],
    "domelementtype@1.3.1": [],
    "domutils@1.7.0": [],
    "entities@2.2.0": [],
    "nth-check@1.0.2": [
      "GHSA-rp65-9cf3-cjxr"
    ]
  },
  "details": {
    "GHSA-rp65-9cf3-cjxr": {
      "id": "GHSA-rp65-9cf3-cjxr",
      "summary": "Inefficient Regular Expression Complexity in nth-check",
      "source": "OSV",
      "published": "2021-09-20T20:47:31Z",
      "modified": "2026-09-10T03:49:08.829841257Z",
      "aliases": ["CVE-2021-3803"],
      "href": "https://osv.dev/vulnerability/GHSA-rp65-9cf3-cjxr",
      "level": "High",
      "score": 7.5
    }
  }
};

// One reconstructed dependency branch. The published Vitest manifest declares the edge.
// Sources: https://registry.npmjs.org/vitest/3.2.6 and the OSV records linked below.
const vitestExampleManifest = {name:'vitest-example',devDependencies:{vitest:'3.2.6'}};
window.LabVitestCapture = {
  captured:'2026-11-21',
  manifest:vitestExampleManifest,
  lock:{lockfileVersion:3,packages:{
    '':vitestExampleManifest,
    'node_modules/vitest':{version:'3.2.6',dev:true,dependencies:{tinypool:'^1.1.1'},
      resolved:'https://registry.npmjs.org/vitest/-/vitest-3.2.6.tgz'},
    'node_modules/tinypool':{version:'1.1.1',dev:true,
      resolved:'https://registry.npmjs.org/tinypool/-/tinypool-1.1.1.tgz'}
  }},
  results:{'tinypool@1.1.1':['GHSA-5gmw-xhrv-c9v3','GHSA-85c8-ppgw-ccpr']},
  details:{
    'GHSA-5gmw-xhrv-c9v3':{
      id:'GHSA-5gmw-xhrv-c9v3',source:'OSV',level:'Critical',score:9.5,
      summary:'Tinypool: Prototype Pollution gadget in worker options leads to Remote Code Execution',
      published:'2026-10-05T22:50:01Z',modified:'2026-10-05T23:00:04.259458991Z',
      aliases:['CVE-2026-104848'],href:'https://osv.dev/vulnerability/GHSA-5gmw-xhrv-c9v3'
    },
    'GHSA-85c8-ppgw-ccpr':{
      id:'GHSA-85c8-ppgw-ccpr',source:'OSV',level:'Critical',score:9.5,
      summary:'Tinypool: Prototype Pollution Gadget to RCE in run() options',
      published:'2026-10-05T22:49:52Z',modified:'2026-10-05T23:00:05.324545780Z',
      aliases:['CVE-2026-104849'],href:'https://osv.dev/vulnerability/GHSA-85c8-ppgw-ccpr'
    }
  }
};
