'use strict';
(() => {
  const currentURL = new URL(location.href);
  // Static hosts can serve the same page at /audit and /audit.html.
  const slug = currentURL.pathname.split('/').pop() || 'index';
  const page = slug.endsWith('.html') ? slug : slug + '.html';
  if (page === 'override.html' && currentURL.hash.startsWith('#scope=')) {
    const old = new URLSearchParams(currentURL.hash.slice(1));
    currentURL.searchParams.set('rev', old.get('scope') === 'before' ? 'base' : 'override');
    currentURL.hash = '#selector-review';
    history.replaceState(null, '', currentURL);
  }
  if (['peers.html', 'tree.html'].includes(page)) {
    const followOldRangeLink = () => {
      if (location.hash !== '#ranges') return;
      const target = new URL('ranges.html', location.href);
      target.search = location.search;
      location.replace(target);
    };
    addEventListener('hashchange', followOldRangeLink);
    followOldRangeLink();
  }
  const languages = ['en','ru'];
  const requested = currentURL.searchParams.get('lang');
  const publicHost = ['.github.io','.chatgpt.site'].some(suffix=>currentURL.hostname.endsWith(suffix));
  let saved;
  try { saved = localStorage.getItem('deploom-lab-language'); } catch {}
  const lang = [requested,saved].find(code=>languages.includes(code)) || (publicHost ? 'en' : 'ru');
  const t = (ru, en) => lang === 'en' ? en : ru;
  if (languages.includes(requested)) {
    try { localStorage.setItem('deploom-lab-language', requested); } catch {}
  }
  document.documentElement.lang = lang;

  function urlFor(path) {
    const url = new URL(path, location.href);
    url.searchParams.set('lang', lang);
    return url.href;
  }
  function link(label, path) {
    const anchor = document.createElement('a');
    anchor.textContent = label;
    anchor.href = urlFor(path);
    return anchor;
  }
  const sections = [
    [t('Инструменты','Tools'), [
      ['audit.html', t('Аудит проекта','Project audit')],
      ['advisories.html', t('Аудит пакета','Package audit')],
      ['plan.html', t('План обновления','Upgrade plan')],
      ['compare.html', t('Сравнить lock-файлы','Compare lockfiles')],
    ]],
    [t('Визуализации','Visualizations'), [
      ['tree.html', t('Дерево зависимостей','Dependency tree')],
      ['tree.html?view=packages', t('Пакеты по группам','Packages by group')],
      ['tree.html?view=groups', t('Группы','Groups')],
      ['ranges.html', t('Проверить диапазон','Check a version range')],
    ]],
  ];
  const main = document.querySelector('main');
  main.id ||= 'main-content';
  const bar = document.createElement('div');
  bar.className = 'bar';
  const skip = document.createElement('a');
  skip.href = '#' + main.id;
  skip.className = 'skip';
  skip.textContent = t('К содержимому','Skip to content');
  const brand = link('DEPLOOM', 'index.html');
  brand.className = 'brand';
  const mark = document.createElement('img');
  mark.src = 'deploom-mark.svg?v=2';
  mark.alt = '';
  mark.width = mark.height = 40;
  brand.prepend(mark);
  const favicon=document.createElement('link'); favicon.rel='icon'; favicon.href=mark.src;document.head.append(favicon);
  const nav = document.createElement('nav');
  nav.setAttribute('aria-label', t('Разделы лаборатории','Lab sections'));
  const home = link(t('Обзор','Overview'), 'index.html');
  nav.append(home);
  if (page === 'index.html') home.setAttribute('aria-current','page');
  for (const [label, items] of sections) {
    const group = document.createElement('details');
    group.className = 'nav-group';
    const summary = document.createElement('summary');
    summary.textContent = label;
    const list = document.createElement('div');
    list.className = 'nav-links';
    for (const [path, title] of items) {
      if (!path) {
        const heading = document.createElement('strong');
        heading.textContent = title;
        list.append(heading);
        continue;
      }
      const anchor = link(title, path);
      const target = new URL(anchor.href);
      if (target.pathname.endsWith('/' + page) && target.searchParams.get('example') === currentURL.searchParams.get('example') && target.hash === currentURL.hash &&
          target.searchParams.get('tool') === currentURL.searchParams.get('tool') && target.searchParams.get('view') === currentURL.searchParams.get('view')) {
        anchor.setAttribute('aria-current','page');
      }
      list.append(anchor);
    }
    group.append(summary, list);
    nav.append(group);
    group.addEventListener('toggle', () => {
      if (group.open) for (const other of nav.querySelectorAll('details[open]')) {
        if (other !== group) other.open = false;
      }
    });
    group.addEventListener('keydown', event => {
      if (event.key === 'Escape') { group.open = false; summary.focus(); }
      if (event.key === 'ArrowDown' && event.target === summary) {
        event.preventDefault(); group.open = true; list.querySelector('a').focus();
      }
    });
    group.addEventListener('focusout', event => {
      if (event.relatedTarget && !group.contains(event.relatedTarget)) group.open = false;
    });
    document.addEventListener('click', event => { if (!group.contains(event.target)) group.open = false; });
  }
  const handbook = link(t('Учебник', 'Handbook'), 'handbook.html');
  if (page === 'handbook.html') handbook.setAttribute('aria-current', 'page');
  nav.append(handbook);
  const language = document.createElement('select');
  language.className = 'language';
  language.setAttribute('aria-label',t('Язык','Language'));
  for (const code of languages) {
    const option = document.createElement('option');
    option.value = option.lang = code;
    option.textContent = code.toUpperCase();
    language.append(option);
  }
  language.value = lang;
  language.addEventListener('change',()=>{
    const url = new URL(location.href);
    url.searchParams.set('lang', language.value);
    location.assign(url.href);
  });
  function setExampleState(fields) {
    const url = new URL(location.href);
    for (const [name, value] of Object.entries(fields)) url.searchParams.set(name, value);
    try { history.replaceState(null, '', url); } catch {}
  }
  bar.append(skip, brand, nav, language);
  window.Lab = { page, lang, t, urlFor, setExampleState };
  document.querySelector('[data-nav]').append(bar);
  if (page !== 'handbook.html') {
    const projectScript = document.createElement('script');
    projectScript.src = 'project.js';
    document.head.append(projectScript);
  }
  if (lang === 'en') for (const element of main.querySelectorAll('[data-en]')) element.textContent = element.dataset.en;
  for (const anchor of main.querySelectorAll('a[href]')) {
    if (/^[\w-]+\.html(?:[?#]|$)/.test(anchor.getAttribute('href'))) anchor.href = urlFor(anchor.getAttribute('href'));
  }
  document.title = (main.querySelector('h1')?.textContent || 'Migration Lab') + ' · DepLoom';
})();
